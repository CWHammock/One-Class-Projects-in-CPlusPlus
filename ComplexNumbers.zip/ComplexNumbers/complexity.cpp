#include <iostream>
#include <string>
#include "complexity.h"

complex::complex():real(0.0), imaginary(0.0)
{}
complex::complex(double real):real(real), imaginary(0.0)
{}
complex::complex(double real, double imaginary):real(real), imaginary(imaginary)
{}
complex complex::operator+ (complex &otherNumber)
{
	complex temp;
	temp.real = this->real+otherNumber.real;
	temp.imaginary = this->imaginary+otherNumber.imaginary;
	return temp;
}
complex complex::operator- (complex &otherNumber)
{
	complex temp;
	temp.real = this->real-otherNumber.real;
	temp.imaginary = this->imaginary-otherNumber.imaginary;
	return temp;
}
/*
const complex complex::operator *(const complex& firstNumber, const complex& otherNumber)
{
	complex temp;
	temp.real = ((firstNumber.real*otherNumber.real)-(firstNumber.imaginary*otherNumber.imaginary));
	temp.imaginary = ((fistNumber.real*otherNumber.imaginary)+(firstNumber.imaginary*otherNumber.real));
	return temp;
}
const complex complex::operator /(const complex &firstNumber, const complex& otherNumber)
{
	complex temp;
	temp.real = this->real+otherNumber.real;
	temp.imaginary = this->imaginary+otherNumber.real;
	return temp;
}
const complex complex::operator <<(const complex& otherNumber)
{
	complex temp;
	temp.real = this->real+otherNumber.real;
	temp.imaginary = this->imaginary+otherNumber.real;
	return temp;
}
const complex complex::operator >>(const complex& otherNumber)
{
	complex temp;
	temp.real = this->real+otherNumber.real;
	temp.imaginary = this->imaginary+otherNumber.real;
	return temp;
}
*/

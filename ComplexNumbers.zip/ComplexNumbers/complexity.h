class complex{

	double real;
	double imaginary;

public:
	complex();
	complex(double real);
	complex(double real, double imaginary);
	complex operator+ (complex &otherNumber);
	complex operator- (complex &otherNumber);
/*
	const complex operator <<(const complex& otherNumber);
	const complex operator >>(const complex& otherNumber);

	friend const complex operator *(const complex &firstNumber, const complex &otherNumber);
	friend const complex operator /(const complex &firstNumber, const complex &otherNumber);
*/
};
